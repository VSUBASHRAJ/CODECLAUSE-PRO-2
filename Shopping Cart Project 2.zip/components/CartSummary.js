import React from 'react';

const CartSummary = ({ total = 0, clearCart, removeFromCart, cart = [] }) => {
  return (
    <div className="cart-summary">
      <h3>Cart Summary</h3>
      {cart.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <>
          {cart.map(item => (
            <div key={item.id} className="cart-item">
              <img src={item.image} alt={item.name} />
              <div>
                <h4>{item.name}</h4>
                <p>${item.price}</p>
                <button className="button" onClick={() => removeFromCart(item.id)}>Remove</button>
              </div>
            </div>
          ))}
          <p>Total: ${total.toFixed(2)}</p>
          <button className="button" onClick={clearCart}>Clear Cart</button>
        </>
      )}
    </div>
  );
};

export default CartSummary;
