import React from 'react';
import ImageUpload from './ImageUpload';

const ProductList = ({ products, addToCart, updateProductImage }) => {
  return (
    <div className="product-list">
      {products.map(product => (
        <div key={product.id} className="product-item">
          <img src={product.image} alt={product.name} style={{ width: '150px', height: '150px' }} />
          <h3>{product.name}</h3>
          <p>${product.price}</p>
          <button className="button" onClick={() => addToCart(product)}>Add to Cart</button>
          <ImageUpload onImageUpload={(imageData) => updateProductImage(product.id, imageData)} />
        </div>
      ))}
    </div>
  );
};

export default ProductList;
