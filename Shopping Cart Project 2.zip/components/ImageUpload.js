import React, { useState } from 'react';

const ImageUpload = ({ onImageUpload }) => {
  const [image, setImage] = useState(null);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const namedImage = {
          name: 'img1',  // Fixed name for the image
          dataUrl: reader.result
        };
        setImage(reader.result);
        onImageUpload(namedImage); // Pass the image data with name to parent
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div>
      <input type="file" accept="image/*" onChange={handleImageChange} />
      {image && <img src={image} alt="Preview" style={{ width: '100px', height: '100px' }} />}
    </div>
  );
};

export default ImageUpload;
