import React from 'react';
import logo from '../images/logo.avif';
const Navbar = ({ 
  cart, 
  cartVisible, 
  setCartVisible, 
  clearCart, 
  calculateTotal, 
  removeFromCart, 
  onSearch // Add onSearch as a prop
}) => {
  return (
    <div className="navbar">
      <div className="logo">E-Commerce</div>
      <div className="search-bar">
        <input 
          type="text" 
          placeholder="Search products..." 
          className="search-bar-input"
          onChange={(e) => onSearch(e.target.value)} // Call onSearch prop
        />
      </div>
      <div className="cart-icon" onClick={() => setCartVisible(!cartVisible)}>
      <img src={logo} alt="Cart" />



        {cart.length > 0 && <span>{cart.length}</span>}
        </div></div>
              
             

)};

export default Navbar;
